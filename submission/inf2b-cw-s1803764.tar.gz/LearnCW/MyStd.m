function s = MyStd(x)
s = sqrt(MyVar(x));
end